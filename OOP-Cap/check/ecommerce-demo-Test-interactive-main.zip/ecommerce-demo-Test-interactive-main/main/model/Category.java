package main.model;

public enum Category {
    CLOTHING,
    FOOTWEAR,
    BACKPACKS,
    TENTS,
    CLIMBING_GEAR,
    LIGHTING,
    CAMP_KITCHEN,
    ELECTRONICS
}